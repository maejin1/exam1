$(function(){
  // 반복문이나 이런거 돌리려면 배열안에 넣어야함~~~ [ ]
  //빈 배열을 준비해 놓고 여기에 img들을 집어넣음~~

  const tagged = {};

  $("#gallery img").each(function(){
    const a = this;                //this라는게 img를 말함~~ 순차적으로 들어감~
    const tags = $(this).data("tags")
  
    if(tags){                             //----> 만약 tags에 값이 있다면..!! 이란 뜻~~!!
      tags.split(",").forEach(function(val){     //----> ,기준으로 나눠서 배열에 넣어라
              if(tagged[val] ==null){            //----> 그 배열안에 값이 없다면
                tagged[val] = [];                //------> 배열을 비워놓기
              }
              tagged[val].push(a);            //----> 배열안에 값이 있다면 / 배열안에 ...img를 넣어라?????? 

      })
    }
  
  })
// -------------------------------------------------------------
  $.each(tagged, function(tagName){
    $("select").on("change",function(){
      const aa=$(this).val();
      if ( aa==""){
        $("#gallery img").show();
      }else {
        $("#gallery img").hide().filter(tagged[aa]).show();
      }


    })
  })



})