$(function(){
  //1. 데이터들(alt, data-tags값, 이미지)을 cache라는 배열에 집어넣음 (each반복문 이용)

  const cache = [];
  $("#gallery img").each(function(){
    cache.push({
      element:this,                    //element는 요소래~ 요소는 img들~~
      text:this.dataset.tags.trim().toLowerCase(),  //text) data-tags도 모아서 넣어놓기
      alt:this.alt.trim().toLowerCase()
    })
  })

// --------------------------------------------------
  $("#filter-search").on("keyup",filter);      //검색창에 키보드를 작성하면
  
  function filter(){
    const search = $(this).val();            //키보드 작성값을 저장해놓음~~
// -----------------------------------------------------(1)
    $("#button ul li").each(function(){       //메뉴 글자들을 반복시킴 (모든 this(=메뉴글자)가 돌면서 글자가 빨간색이 되는 걸 돌음~~)
                                            //★each에 this가 들어가면 this에 해당하는 게 몇백개든 다 돌면서 적용이 된다~~   
         const a = $(this).text();          //메뉴의 글자~ (this는 메뉴!)
         const b = $(this).attr("id")       //메뉴의 id값~ (메뉴의 id값을 이미지의 alt값과 맞춰놓음~)
      if(a == "all") {
            $(".first a").removeClass("active");   //(?)all인데 왜 빨간색글자를 뺴지? 넣어야 하는거 아닌가?
           $("#gallery img").show();
        }
      if(search ==""){                     //검색창 내용이 없다면 
          $(".first a").addClass("active");
          $("#gallery img").show();
        }
       if(search==a ||search==b){
        $(this).addClass("active");         //여기서 this는 메뉴~~~!!!!! (검색창 글자 아님~~!!)
       } else{
        $(this).removeClass("active");
       }
    });
// ----------------------------------------------------------(2)
    const c = this.value.trim().toLowerCase();   //----> this란 검색창을 말하는듯..!
                                                 //---> 검색창에 나온 값~
    cache.forEach(function(d){
        let x;
        let eng = /[a-zA-Z]/;               //영문자로만 구성된 값
      
      if(c){
        if(eng.test(c)){                  // test(x)란?  --> x가 정규포현식 eng를 만족하는지에 따라 true, false로 나옴
                                          //=> 영어가 검색창내에서 있는가? 맞으면 true, 아니면 fasle
        x = d.alt.indexOf(c);             //indexOf(c)  -> c값을 찾는 함수임~~ / c값이 없으면 -1로 나옴~~
                                          //=> 영어값이 있으면 cache(배열)의 alt값을 c에서 찾아라 (없으면 -1)
        }else {
          x = d.text.indexOf(c);         //=> 영어값이 없으면 cache의 text값을 c에서 찾아라
        }
      }

      d.element.style.display = x === -1 ? "none" : "";
    })

  }   //filter 함수 끝
// ---------------------------------------------------------------
const tagged = {};                         //tagged라는 새로운 배열을 만듦
$("#gallery img").each(function(){
  const i = this;                          //여기서 this -> gallery의 img임~~
  const t = $(this).data("tags");          //img의 data-tags를 뽑아냄~~

  if(t) {                                //만약 t(=data-tags)가 존재한다면
    t.split(",").forEach(function(j){     //tags를 잘라서 반복문에 돌린다
      if(tagged[j]==null){                //tagged배열이 값이없다면
          tagged[j] = [];                 //빈방으로 만들기
      }
          tagged[j].push(i);               //★그게 아니라면 그 태그값에 해당하는 이미지를 넣기!!! (같은방에~~!!!)
    })
  }
})

// ----------------------------------------------------------------
$(".first a").on("click", function(){
  $("#button li").removeClass("active");
  $(this).addClass("active");
  $("#gallery img").show();
  return false;
});
// ------------------------------------------------------------------
$.each(tagged, function(y){
  $("#button li").on("click", function(){           //메뉴를 클릭하면
    $(".first a").removeClass("active");
    const ee = $(this).text();                //this는 메뉴~~ 메뉴에 있는 글자를 말함
    $(this).addClass("active").siblings().removeClass("active")   //siblings는 형제란 뜻이래... 즉, 선택된 애만 빨간색 글씨 표시되게...(선택된 애는 빨간색, 그 형제들은 빨간색 지우기)
    $("#gallery img").hide().filter(tagged[ee]).show(); //filter()는 함수래!!!!!
                                                       //
    /* tagged[ee] 란 ee가 메뉴에 있는 글자를 말하므로
       tagged 란 배열에 ee의 방을 말함 ex) tagged[바다동물] 이란 방에
      그 메뉴의 글자와 똑같은걸 tagged배열에 data-tags로 넣어놨었고,
      (69번에 보면) 그에 해당하는 이미지까지 넣어놨으므로
      메뉴의 글자(=ee)에 해당하는 이미지를 불러올 수 있는것~~

    */
  })
})




})