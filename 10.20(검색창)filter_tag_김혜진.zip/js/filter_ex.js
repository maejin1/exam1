
const cache = [];
function filter(){

$("#gallery img").each(function(){
  cache.push({
    element:this,          //img가 this~
    text: this.alt.trim().toLowerCase()
  })
})

const query = document.getElementById("filter-search").value.trim().toLowerCase();
cache.forEach(function(am){
  let cc=0;
  if(query) {
    cc = am.text.indexOf(query);
  }
  am.element.style.display = cc == -1 ? "none" : "";
})  



}